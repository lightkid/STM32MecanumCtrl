/*
 * encoder.c
 *
 *  Created on: Aug 29, 2023
 *      Author: lenovo
 */

#include "encoder.h"

Encoder encoders[4];
void InitEncoders()
{
	for (int i=0;i<4;i++)
	{
		encoders[i].counter = 0;
		encoders[i].len = 0;
	}
}
void updateMotorSpeed(uint8_t triggle_time_ms)
{
	uint8_t i = 0;
    for (i=0; i<4; i++)
    {
        int32_t counter = encoders[i].counter;
        encoders[i].xr_phase += encoders[i].counter;
        encoders[i].counter = 0;

        float pulse_1m = 1.0;
        if (ENCODER_A_INDEX == i)  pulse_1m = (float)ENCODER_A_PULSE_NUMBER_PER_1M;
        else if (ENCODER_B_INDEX == i)  pulse_1m = (float)ENCODER_B_PULSE_NUMBER_PER_1M;
        else if (ENCODER_C_INDEX == i)  pulse_1m = (float)ENCODER_C_PULSE_NUMBER_PER_1M;
        else if (ENCODER_D_INDEX == i)  pulse_1m = (float)ENCODER_D_PULSE_NUMBER_PER_1M;
        else    return;

        if (encoders[i].len != ENCODER_WINDOW_LEN)
        {  // 如果未达到长度
        	uint8_t index = encoders[i].len;
        	encoders[i].len++;
        	encoders[i].queue[index] = counter;
        }
        else
        {
        	for (uint8_t j=0;j<ENCODER_WINDOW_LEN-1;j++)
        	{  // 左移出队列
        		encoders[i].queue[j] = encoders[i].queue[j+1];
        	}
        	encoders[i].queue[ENCODER_WINDOW_LEN-1] = counter;
        }
        int32_t avgCounter = 0;
        for (uint8_t j=0;j<encoders[i].len;j++)
        {
        	avgCounter += encoders[i].queue[j];
        }
//        avgCounter /= encoders[i].len;
//        encoders[i].avgCounter = avgCounter;

        encoders[i].rpm = ( ((float)avgCounter)*60.0f / pulse_1m ) / (0.001f * ((float)triggle_time_ms)*encoders[i].len);
    }
}

