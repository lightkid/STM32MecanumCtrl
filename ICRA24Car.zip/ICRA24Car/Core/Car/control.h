/*
 * control.h
 *
 *  Created on: 2023年9月5日
 *      Author: lenovo
 */

#ifndef CAR_CONTROL_H_
#define CAR_CONTROL_H_

#include "math.h"

typedef struct _PIDStruct
{
	float req;
	float feedback;
	// param
	float Kp;
	float Ki;
	float Kd;
	// e
	float err_k;
	float err_k1;  // k-1
	float err_k2;  // k-2
	float dderr;
	float derr;
	// output
	float u;
	float delta_u;
	float Kpu;
	float Kiu;
	float Kdu;
	// clamp
	float u_max;
	float u_min;
} PIDStruct;

void initPID(PIDStruct* stru);
void resetPID(PIDStruct* stru);
void updatePID(PIDStruct* stru);

#endif /* CAR_CONTROL_H_ */
