/*
 * protocol.h
 *
 *  Created on: Aug 29, 2023
 *      Author: lenovo
 */

#ifndef CAR_PROTOCOL_H_
#define CAR_PROTOCOL_H_
#include "stm32f1xx_hal.h"
#define PROTOCOL_BUFFER_SIZE 255
#define HX_CMD_LEN 15
typedef struct _RobotRecevie_t
{
	uint8_t rxBuffer[PROTOCOL_BUFFER_SIZE];  // raw Buffer
	uint8_t len;
	float vx;
	float vy;
	float omega;
} RobotReceive_t;

typedef struct _RobotSend_t
{
	uint8_t txBuffer[PROTOCOL_BUFFER_SIZE];
	uint8_t len;
	float motorFeedbackSpd[4];  // rpm
	float motorReqSpd[4];  // rpm
//	float vx;
//	float vy;
//	float omega;
	// resevered
} RobotSend_t;

extern RobotReceive_t receiver;
extern RobotSend_t uart6Sender;

uint8_t decodeCommand(RobotReceive_t* recevier);
uint8_t encodeFeedback(RobotSend_t* fdbk);

#endif /* CAR_PROTOCOL_H_ */
