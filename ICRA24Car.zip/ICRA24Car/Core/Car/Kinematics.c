/*
 * Kinematics.c
 *
 *  Created on: Aug 30, 2023
 *      Author: lenovo
 */
#include "Kinematics.h"

/**
 * @brief 从车体的速度变换到电机转速
 * @param cmd [vx,vy,omega],m/s & rad/s
 * @param motorRPM r/min
 */
void solveIK(float* cmd,float* motorRPM)
{
	motorRPM[0]= (cmd[0]-cmd[1]-(RADIUS_X+RADIUS_Y)*cmd[2])*RAD2RPM/WHEEL_RADIUS;
	motorRPM[1]= (cmd[0]+cmd[1]-(RADIUS_X+RADIUS_Y)*cmd[2])*RAD2RPM/WHEEL_RADIUS;
	motorRPM[2]= (cmd[0]-cmd[1]+(RADIUS_X+RADIUS_Y)*cmd[2])*RAD2RPM/WHEEL_RADIUS;
	motorRPM[3]= (cmd[0]+cmd[1]+(RADIUS_X+RADIUS_Y)*cmd[2])*RAD2RPM/WHEEL_RADIUS;
}

void solveFK(float* motorRPM,float* carVel)
{
	carVel[0] = WHEEL_RADIUS*(motorRPM[0]+motorRPM[1]+motorRPM[2]+motorRPM[3])*RPM2RAD/4.0f;
	carVel[1] = WHEEL_RADIUS*(-motorRPM[0]+motorRPM[1]-motorRPM[2]+motorRPM[3])*RPM2RAD/4.0f;
	carVel[2] = WHEEL_RADIUS*(-motorRPM[0]-motorRPM[1]+motorRPM[2]+motorRPM[3])*RPM2RAD/(4.0f*(RADIUS_X+RADIUS_Y));
}

void simpleControl(float* cmd)
{
	float motorRPM[4];
	solveIK(cmd,motorRPM);
	for (int i=0;i<4;i++)
	{
		float rpm = motorRPM[i];
		if (rpm > 500)
		{
			rpm = 500;
		}
		else if (rpm < -500)
		{
			rpm = -500;
		}
		float dutyCycle = rpm*8.0f/2000;
		if (i < 2)
		{
			dutyCycle *= -1;
		}
		CtrlMotor(i,dutyCycle);
	}
}

void PIDControl(float* cmd,float* motorFeedback,PIDStruct* pid)
{
	float motorRPM[4];
	solveIK(cmd,motorRPM);
	for (int i=0;i<4;i++)
	{
		pid[i].feedback = motorFeedback[i];
		pid[i].req = motorRPM[i];
		updatePID(&pid[i]);
		float dutyCycle = pid[i].u;
		if (i < 2)
		{
			dutyCycle *= -1;
		}
		//encoders[i].xr_phase -= motorRPM[i] / 60.0f / 200.0f * HALL_MAG_NUM * MOTOR_RATIO * 4;
		//dutyCycle = encoders[i].xr_phase * 0.0f;
		//if (i > 1)
		//{
		//	dutyCycle *= -1;
		//}
		//if(dutyCycle > 1.0) dutyCycle = 1.0;
		//if(dutyCycle < -1.0) dutyCycle = -1.0;
		//if(i == 3) dutyCycle = 1.0f;
		//dutyCycle = 0.5f;
		CtrlMotor(i,dutyCycle);
	}
}
