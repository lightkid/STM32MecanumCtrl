/*
 * Motor.h
 *
 *  Created on: Aug 29, 2023
 *      Author: lenovo
 */

#ifndef CAR_MOTOR_H_
#define CAR_MOTOR_H_

#include "stm32f1xx_hal.h"
#include "math.h"

extern TIM_HandleTypeDef htim2;
extern TIM_HandleTypeDef htim4;

void InitMotors();
void DisableMotors();

void CtrlMotor(int id,float dutyCycle);

#endif /* CAR_MOTOR_H_ */
