/*
 * control.c
 *
 *  Created on: 2023年9月5日
 *      Author: lenovo
 */

#include "control.h"

void initPID(PIDStruct* stru)
{
	stru->u = 0;
	stru->delta_u = 0;
	stru->req = 0;
	stru->feedback = 0;

	stru->err_k = 0;
	stru->err_k1 = 0;
	stru->err_k2 = 0;
	stru->derr = 0;
	stru->derr = 0;

	stru->Kpu = 0;
	stru->Kiu = 0;
	stru->Kdu = 0;

	stru->Kp = 0;
	stru->Ki = 0;
	stru->Kd = 0;
}

void resetPID(PIDStruct* stru)
{
	stru->u = 0;
	stru->delta_u = 0;
	stru->req = 0;
	stru->feedback = 0;

	stru->err_k = 0;
	stru->err_k1 = 0;
	stru->err_k2 = 0;
	stru->derr = 0;
	stru->dderr = 0;

	stru->Kpu = 0;
	stru->Kiu = 0;
	stru->Kdu = 0;
}

void updatePID(PIDStruct* stru)
{
	// update err
	stru->err_k2 = stru->err_k1;
	stru->err_k1 = stru->err_k;
	stru->err_k = stru->req -stru->feedback;
	stru->derr = stru->err_k - stru->err_k1;
	stru->dderr = stru->err_k + stru->err_k2 - 2*stru->err_k1;
	// calc delta u
	stru->Kpu = stru->Kp*stru->derr;
	stru->Kdu = stru->Kd*stru->dderr;
	stru->Kiu = stru->Ki*stru->err_k;
	stru->delta_u = stru->Kpu + stru->Kiu + stru->Kdu;
	// calc output
	stru->u += stru->delta_u;
	if (stru->u > stru->u_max)
	{
		stru->u = stru->u_max;
	}
	else if (stru->u < stru->u_min)
	{
		stru->u = stru->u_min;
	}
}
