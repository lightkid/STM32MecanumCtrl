/*
 * encoder.h
 *
 *  Created on: Aug 29, 2023
 *      Author: lenovo
 */

#ifndef CAR_ENCODER_H_
#define CAR_ENCODER_H_

#include "stm32f1xx_hal.h"
//
#define ENCODER_WINDOW_LEN 8
#define EDGE_PSC 2 // 上升下降沿触发，2倍频
#define HALL_MAG_NUM 12  // 一圈12个脉冲
#define MOTOR_RATIO 19  // 减速比
// 编码器引脚
#define ENCODER_A_LEVEL                     PB3
#define ENCODER_A_TRIGGLE                   PC9
#define ENCODER_A_LINE                      EXTI_Line9
#define ENCODER_A_PULSE_NUMBER_PER_1M       HALL_MAG_NUM*MOTOR_RATIO*EDGE_PSC
#define ENCODER_A_DIR                       0
#define ENCODER_A_INDEX                     0U

#define ENCODER_B_LEVEL                     PB4
#define ENCODER_B_TRIGGLE                   PC8
#define ENCODER_B_LINE                      EXTI_Line8
#define ENCODER_B_PULSE_NUMBER_PER_1M       HALL_MAG_NUM*MOTOR_RATIO
#define ENCODER_B_DIR                       0
#define ENCODER_B_INDEX                     1U

#define ENCODER_C_LEVEL                     PB5
#define ENCODER_C_TRIGGLE                   PC7
#define ENCODER_C_LINE                      EXTI_Line7
#define ENCODER_C_PULSE_NUMBER_PER_1M       HALL_MAG_NUM*MOTOR_RATIO
#define ENCODER_C_DIR                       1
#define ENCODER_C_INDEX                     2U

#define ENCODER_D_LEVEL                     PA11
#define ENCODER_D_TRIGGLE                   PC6
#define ENCODER_D_LINE                      EXTI_Line6
#define ENCODER_D_PULSE_NUMBER_PER_1M       HALL_MAG_NUM*MOTOR_RATIO
#define ENCODER_D_DIR                       1
#define ENCODER_D_INDEX                     3U

typedef struct _Encoder_t
{
	float rpm;
	int32_t counter;
	//int32_t avgCounter;
	int32_t queue[10];  // history
	uint8_t len;  // queue length
	float xr_phase;
} Encoder;

extern Encoder encoders[4];
void InitEncoders();
void updateMotorSpeed(uint8_t triggle_time_ms);

#endif /* CAR_ENCODER_H_ */
