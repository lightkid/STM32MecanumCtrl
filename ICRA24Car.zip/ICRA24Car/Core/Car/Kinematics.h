/*
 * Kinematics.h
 *
 *  Created on: Aug 30, 2023
 *      Author: lenovo
 */

#ifndef CAR_KINEMATICS_H_
#define CAR_KINEMATICS_H_

#include "math.h"
#include "encoder.h"
#include "Motor.h"
#include "control.h"

#define WHEEL_RADIUS 0.0275  // M
#define RADIUS_X 0.05
#define RADIUS_Y 0.075
#define RPM2RAD 0.1046667
#define RAD2RPM 9.554

#define MAX_VELOCITY 1.5
#define MAX_OMEGA 0.2
void solveIK(float* cmd,float* motorRPM);
void solveFK(float* motorRPM,float* carVel);

void simpleControl(float* cmd);
void PIDControl(float* cmd,float* motorFeedback,PIDStruct* pid);
#endif /* CAR_KINEMATICS_H_ */
