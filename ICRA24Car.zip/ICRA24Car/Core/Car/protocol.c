/*
 * protocol.c
 *
 *  Created on: Aug 29, 2023
 *      Author: lenovo
 */


#include "protocol.h"

RobotReceive_t receiver;
RobotSend_t uart6Sender;
/**
 * @brief 根据接收解码
 * @note 0xFF 0XFE (Header) vx vy vz(int16_t ,x1000)  0xFF
 */
uint8_t decodeCommand(RobotReceive_t* recevier)
{
	if (recevier->len == HX_CMD_LEN)
	{  // 定长
		if (recevier->rxBuffer[0] == 0xFF && recevier->rxBuffer[1] == 0xFE)
		{
			float* decodePtr = (float*)(&recevier->rxBuffer[2]);
			recevier->vx = (float)(decodePtr[0])/1000.0f;
			recevier->vy = (float)(decodePtr[1])/1000.0f;
			recevier->omega = (float)(decodePtr[2])/1000.0f;
		}
		else
		{
			return 254;
		}
		return 0;
	}
	else
	{
		return 255;
	}

}

/**
 *
 */
uint8_t encodeFeedback(RobotSend_t* fdbk)
{
	fdbk->len = 8*4+3;  // 8float
	fdbk->txBuffer[0] = 0xFF;
	fdbk->txBuffer[1] = 0XFE;
	fdbk->txBuffer[2] = 0x08;
	float* ptr = (float*)(&fdbk->txBuffer[3]);
	ptr[0] = fdbk->motorReqSpd[0];
	ptr[1] = fdbk->motorReqSpd[1];
	ptr[2] = fdbk->motorReqSpd[2];
	ptr[3] = fdbk->motorReqSpd[3];
	ptr[4] = fdbk->motorFeedbackSpd[0];
	ptr[5] = fdbk->motorFeedbackSpd[1];
	ptr[6] = fdbk->motorFeedbackSpd[2];
	ptr[7] = fdbk->motorFeedbackSpd[3];  // 3+4*8
	int index = 3+4*8;
	fdbk->txBuffer[index] = 0XFF;
	return 0;
}
