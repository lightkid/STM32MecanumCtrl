/*
 * Motor.c
 *
 *  Created on: Aug 29, 2023
 *      Author: lenovo
 */

#include "Motor.h"
#include "main.h"
void InitMotors()
{
	// set CCR
	__HAL_TIM_SetCompare(&htim2, TIM_CHANNEL_1,0);
	__HAL_TIM_SetCompare(&htim2, TIM_CHANNEL_2,0);
	__HAL_TIM_SetCompare(&htim2, TIM_CHANNEL_3,0);
	__HAL_TIM_SetCompare(&htim2, TIM_CHANNEL_4,0);

	__HAL_TIM_SetCompare(&htim4, TIM_CHANNEL_1,0);
	__HAL_TIM_SetCompare(&htim4, TIM_CHANNEL_2,0);
	__HAL_TIM_SetCompare(&htim4, TIM_CHANNEL_3,0);
	__HAL_TIM_SetCompare(&htim4, TIM_CHANNEL_4,0);

	HAL_TIM_PWM_Start(&htim2, TIM_CHANNEL_1);
	HAL_TIM_PWM_Start(&htim2, TIM_CHANNEL_2);
	HAL_TIM_PWM_Start(&htim2, TIM_CHANNEL_3);
	HAL_TIM_PWM_Start(&htim2, TIM_CHANNEL_4);

	HAL_TIM_PWM_Start(&htim4, TIM_CHANNEL_1);
	HAL_TIM_PWM_Start(&htim4, TIM_CHANNEL_2);
	HAL_TIM_PWM_Start(&htim4, TIM_CHANNEL_3);
	HAL_TIM_PWM_Start(&htim4, TIM_CHANNEL_4);

	// enable
	HAL_GPIO_WritePin(GPIOA, GPIO_PIN_15,GPIO_PIN_SET);  // AB Enabe
	HAL_GPIO_WritePin(GPIOC, GPIO_PIN_0,GPIO_PIN_SET);  // CD

}

/**
 * @brief 失能电机
 */
void DisableMotors()
{
	// set CCR
	__HAL_TIM_SetCompare(&htim2, TIM_CHANNEL_1,0);
	__HAL_TIM_SetCompare(&htim2, TIM_CHANNEL_2,0);
	__HAL_TIM_SetCompare(&htim2, TIM_CHANNEL_3,0);
	__HAL_TIM_SetCompare(&htim2, TIM_CHANNEL_4,0);

	__HAL_TIM_SetCompare(&htim4, TIM_CHANNEL_1,0);
	__HAL_TIM_SetCompare(&htim4, TIM_CHANNEL_2,0);
	__HAL_TIM_SetCompare(&htim4, TIM_CHANNEL_3,0);
	__HAL_TIM_SetCompare(&htim4, TIM_CHANNEL_4,0);

	// disable
	HAL_GPIO_WritePin(GPIOA, GPIO_PIN_15,GPIO_PIN_RESET);  // AB Enabe
	HAL_GPIO_WritePin(GPIOC, GPIO_PIN_0,GPIO_PIN_RESET);  // CD
}

/**
 * @brief 控制电机
 * @param id，电机ID,[0,1,2,3]
 * @param dutyCycle, 占空比 [-1,1]
 */
void CtrlMotor(int id,float dutyCycle)
{
	uint16_t CCR = (uint16_t)(fabs(dutyCycle)*2000);
	if (CCR > 2000){CCR = 2000;}
	static float deadZone = 0.1;  // hyper param
	switch (id)
	{
	case 0:
	{
		if (dutyCycle > deadZone)
		{  // Motor 1 ,clockwise
			__HAL_TIM_SetCompare(&htim2, TIM_CHANNEL_1,CCR);
			__HAL_TIM_SetCompare(&htim2, TIM_CHANNEL_2,0);
		}
		else if (dutyCycle < -deadZone)
		{
			// Motor 1 ,counter-clockwise
			__HAL_TIM_SetCompare(&htim2, TIM_CHANNEL_2,CCR);
			__HAL_TIM_SetCompare(&htim2, TIM_CHANNEL_1,0);
		}
		else
		{
			__HAL_TIM_SetCompare(&htim2, TIM_CHANNEL_2,0);
			__HAL_TIM_SetCompare(&htim2, TIM_CHANNEL_1,0);
		}
		break;
	}
	case 1:
	{
		if (dutyCycle > deadZone)
		{  // Motor 2 ,clockwise
			__HAL_TIM_SetCompare(&htim2, TIM_CHANNEL_3,CCR);
			__HAL_TIM_SetCompare(&htim2, TIM_CHANNEL_4,0);
		}
		else if (dutyCycle < -deadZone)
		{
			// Motor 2 ,counter-clockwise
			__HAL_TIM_SetCompare(&htim2, TIM_CHANNEL_4,CCR);
			__HAL_TIM_SetCompare(&htim2, TIM_CHANNEL_3,0);
		}
		else
		{
			__HAL_TIM_SetCompare(&htim2, TIM_CHANNEL_3,0);
			__HAL_TIM_SetCompare(&htim2, TIM_CHANNEL_4,0);
		}
		break;
	}
	case 2:
	{
		if (dutyCycle > deadZone)
		{  // Motor C ,clockwise
			__HAL_TIM_SetCompare(&htim4, TIM_CHANNEL_1,CCR);
			__HAL_TIM_SetCompare(&htim4, TIM_CHANNEL_2,0);
		}
		else if (dutyCycle < -deadZone)
		{
			// Motor C ,counter-clockwise
			__HAL_TIM_SetCompare(&htim4, TIM_CHANNEL_2,CCR);
			__HAL_TIM_SetCompare(&htim4, TIM_CHANNEL_1,0);
		}
		else
		{
			__HAL_TIM_SetCompare(&htim4, TIM_CHANNEL_2,0);
			__HAL_TIM_SetCompare(&htim4, TIM_CHANNEL_1,0);
		}
		break;
	}
	case 3:
	{
		if (dutyCycle > deadZone)
		{  // Motor D ,clockwise
			__HAL_TIM_SetCompare(&htim4, TIM_CHANNEL_3,CCR);
			__HAL_TIM_SetCompare(&htim4, TIM_CHANNEL_4,0);
		}
		else if (dutyCycle < -deadZone)
		{
			// Motor 1 ,counter-clockwise
			__HAL_TIM_SetCompare(&htim4, TIM_CHANNEL_4,CCR);
			__HAL_TIM_SetCompare(&htim4, TIM_CHANNEL_3,0);
		}
		else
		{
			__HAL_TIM_SetCompare(&htim4, TIM_CHANNEL_3,0);
			__HAL_TIM_SetCompare(&htim4, TIM_CHANNEL_4,0);
		}
		break;
	}
	default : {break;}
	}
	return ;
}

