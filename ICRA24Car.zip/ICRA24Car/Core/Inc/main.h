/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.h
  * @brief          : Header for main.c file.
  *                   This file contains the common defines of the application.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2023 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32f1xx_hal.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "Motor.h"
#include "protocol.h"
#include "Kinematics.h"
/* USER CODE END Includes */

/* Exported types ------------------------------------------------------------*/
/* USER CODE BEGIN ET */

/* USER CODE END ET */

/* Exported constants --------------------------------------------------------*/
/* USER CODE BEGIN EC */

/* USER CODE END EC */

/* Exported macro ------------------------------------------------------------*/
/* USER CODE BEGIN EM */

/* USER CODE END EM */

void HAL_TIM_MspPostInit(TIM_HandleTypeDef *htim);

/* Exported functions prototypes ---------------------------------------------*/
void Error_Handler(void);

/* USER CODE BEGIN EFP */

/* USER CODE END EFP */

/* Private defines -----------------------------------------------------------*/
#define MOTOR_CDEN_Pin GPIO_PIN_0
#define MOTOR_CDEN_GPIO_Port GPIOC
#define MOTOR_A1_Pin GPIO_PIN_0
#define MOTOR_A1_GPIO_Port GPIOA
#define MOTOR_A2_Pin GPIO_PIN_1
#define MOTOR_A2_GPIO_Port GPIOA
#define MOTOR_B1_Pin GPIO_PIN_2
#define MOTOR_B1_GPIO_Port GPIOA
#define MOTOR_B2_Pin GPIO_PIN_3
#define MOTOR_B2_GPIO_Port GPIOA
#define HALL_D2_Pin GPIO_PIN_6
#define HALL_D2_GPIO_Port GPIOC
#define HALL_D2_EXTI_IRQn EXTI9_5_IRQn
#define HALL_C2_Pin GPIO_PIN_7
#define HALL_C2_GPIO_Port GPIOC
#define HALL_C2_EXTI_IRQn EXTI9_5_IRQn
#define HALL_B2_Pin GPIO_PIN_8
#define HALL_B2_GPIO_Port GPIOC
#define HALL_B2_EXTI_IRQn EXTI9_5_IRQn
#define HALL_A2_Pin GPIO_PIN_9
#define HALL_A2_GPIO_Port GPIOC
#define HALL_A2_EXTI_IRQn EXTI9_5_IRQn
#define HALL_D1_Pin GPIO_PIN_11
#define HALL_D1_GPIO_Port GPIOA
#define MOTOR_ABEN_Pin GPIO_PIN_15
#define MOTOR_ABEN_GPIO_Port GPIOA
#define HALL_A1_Pin GPIO_PIN_3
#define HALL_A1_GPIO_Port GPIOB
#define HALL_B1_Pin GPIO_PIN_4
#define HALL_B1_GPIO_Port GPIOB
#define HALL_C1_Pin GPIO_PIN_5
#define HALL_C1_GPIO_Port GPIOB
#define MOTOR_C1_Pin GPIO_PIN_6
#define MOTOR_C1_GPIO_Port GPIOB
#define MOTOR_C2_Pin GPIO_PIN_7
#define MOTOR_C2_GPIO_Port GPIOB
#define MOTOR_D1_Pin GPIO_PIN_8
#define MOTOR_D1_GPIO_Port GPIOB
#define MOTOR_D2_Pin GPIO_PIN_9
#define MOTOR_D2_GPIO_Port GPIOB

/* USER CODE BEGIN Private defines */

/* USER CODE END Private defines */

#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H */
