/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file    stm32f1xx_it.c
  * @brief   Interrupt Service Routines.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2023 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "stm32f1xx_it.h"
/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "protocol.h"
#include "Motor.h"
#include "encoder.h"
#include "Kinematics.h"
#include "control.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN TD */

/* USER CODE END TD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/* External variables --------------------------------------------------------*/
extern TIM_HandleTypeDef htim5;
extern DMA_HandleTypeDef hdma_uart4_rx;
extern DMA_HandleTypeDef hdma_usart1_rx;
extern UART_HandleTypeDef huart4;
extern UART_HandleTypeDef huart1;
/* USER CODE BEGIN EV */
extern PIDStruct MotorPID;
/* USER CODE END EV */

/******************************************************************************/
/*           Cortex-M3 Processor Interruption and Exception Handlers          */
/******************************************************************************/
/**
  * @brief This function handles Non maskable interrupt.
  */
void NMI_Handler(void)
{
  /* USER CODE BEGIN NonMaskableInt_IRQn 0 */

  /* USER CODE END NonMaskableInt_IRQn 0 */
  /* USER CODE BEGIN NonMaskableInt_IRQn 1 */
  while (1)
  {
  }
  /* USER CODE END NonMaskableInt_IRQn 1 */
}

/**
  * @brief This function handles Hard fault interrupt.
  */
void HardFault_Handler(void)
{
  /* USER CODE BEGIN HardFault_IRQn 0 */

  /* USER CODE END HardFault_IRQn 0 */
  while (1)
  {
    /* USER CODE BEGIN W1_HardFault_IRQn 0 */
    /* USER CODE END W1_HardFault_IRQn 0 */
  }
}

/**
  * @brief This function handles Memory management fault.
  */
void MemManage_Handler(void)
{
  /* USER CODE BEGIN MemoryManagement_IRQn 0 */

  /* USER CODE END MemoryManagement_IRQn 0 */
  while (1)
  {
    /* USER CODE BEGIN W1_MemoryManagement_IRQn 0 */
    /* USER CODE END W1_MemoryManagement_IRQn 0 */
  }
}

/**
  * @brief This function handles Prefetch fault, memory access fault.
  */
void BusFault_Handler(void)
{
  /* USER CODE BEGIN BusFault_IRQn 0 */

  /* USER CODE END BusFault_IRQn 0 */
  while (1)
  {
    /* USER CODE BEGIN W1_BusFault_IRQn 0 */
    /* USER CODE END W1_BusFault_IRQn 0 */
  }
}

/**
  * @brief This function handles Undefined instruction or illegal state.
  */
void UsageFault_Handler(void)
{
  /* USER CODE BEGIN UsageFault_IRQn 0 */

  /* USER CODE END UsageFault_IRQn 0 */
  while (1)
  {
    /* USER CODE BEGIN W1_UsageFault_IRQn 0 */
    /* USER CODE END W1_UsageFault_IRQn 0 */
  }
}

/**
  * @brief This function handles System service call via SWI instruction.
  */
void SVC_Handler(void)
{
  /* USER CODE BEGIN SVCall_IRQn 0 */

  /* USER CODE END SVCall_IRQn 0 */
  /* USER CODE BEGIN SVCall_IRQn 1 */

  /* USER CODE END SVCall_IRQn 1 */
}

/**
  * @brief This function handles Debug monitor.
  */
void DebugMon_Handler(void)
{
  /* USER CODE BEGIN DebugMonitor_IRQn 0 */

  /* USER CODE END DebugMonitor_IRQn 0 */
  /* USER CODE BEGIN DebugMonitor_IRQn 1 */

  /* USER CODE END DebugMonitor_IRQn 1 */
}

/**
  * @brief This function handles Pendable request for system service.
  */
void PendSV_Handler(void)
{
  /* USER CODE BEGIN PendSV_IRQn 0 */

  /* USER CODE END PendSV_IRQn 0 */
  /* USER CODE BEGIN PendSV_IRQn 1 */

  /* USER CODE END PendSV_IRQn 1 */
}

/**
  * @brief This function handles System tick timer.
  */
void SysTick_Handler(void)
{
  /* USER CODE BEGIN SysTick_IRQn 0 */

  /* USER CODE END SysTick_IRQn 0 */
  HAL_IncTick();
  /* USER CODE BEGIN SysTick_IRQn 1 */

  /* USER CODE END SysTick_IRQn 1 */
}

/******************************************************************************/
/* STM32F1xx Peripheral Interrupt Handlers                                    */
/* Add here the Interrupt Handlers for the used peripherals.                  */
/* For the available peripheral interrupt handler names,                      */
/* please refer to the startup file (startup_stm32f1xx.s).                    */
/******************************************************************************/

/**
  * @brief This function handles DMA1 channel5 global interrupt.
  */
void DMA1_Channel5_IRQHandler(void)
{
  /* USER CODE BEGIN DMA1_Channel5_IRQn 0 */

  /* USER CODE END DMA1_Channel5_IRQn 0 */
  HAL_DMA_IRQHandler(&hdma_usart1_rx);
  /* USER CODE BEGIN DMA1_Channel5_IRQn 1 */

  /* USER CODE END DMA1_Channel5_IRQn 1 */
}

/**
  * @brief This function handles EXTI line[9:5] interrupts.
  */
void EXTI9_5_IRQHandler(void)
{
  /* USER CODE BEGIN EXTI9_5_IRQn 0 */

  /* USER CODE END EXTI9_5_IRQn 0 */
  HAL_GPIO_EXTI_IRQHandler(HALL_D2_Pin);
  HAL_GPIO_EXTI_IRQHandler(HALL_C2_Pin);
  HAL_GPIO_EXTI_IRQHandler(HALL_B2_Pin);
  HAL_GPIO_EXTI_IRQHandler(HALL_A2_Pin);
  /* USER CODE BEGIN EXTI9_5_IRQn 1 */

  /* USER CODE END EXTI9_5_IRQn 1 */
}

/**
  * @brief This function handles USART1 global interrupt.
  */
void USART1_IRQHandler(void)
{
  /* USER CODE BEGIN USART1_IRQn 0 */
//	  uint32_t tmp_flag = 0;
//	     uint32_t temp;
  /* USER CODE END USART1_IRQn 0 */
  HAL_UART_IRQHandler(&huart1);
  /* USER CODE BEGIN USART1_IRQn 1 */
//     if(USART1 == huart1.Instance)
//     {
//         tmp_flag =__HAL_UART_GET_FLAG(&huart1,UART_FLAG_IDLE); //获取IDLE标志�???
//
//         if((tmp_flag != RESET))//idle标志被置�???
//         {
//             recv_end_flag = 1;  // 接受完成标志位置1
//             __HAL_UART_CLEAR_IDLEFLAG(&huart1);//清除标志�???
//
//             HAL_UART_DMAStop(&huart1); //
//             temp  =  __HAL_DMA_GET_COUNTER(&hdma_usart1_rx);// 获取DMA中未传输的数据个�???
//             receiver.len =  PROTOCOL_BUFFER_SIZE - temp; //总计数减去未传输的数据个数，得到已经接收的数据个�???
//
//             HAL_UART_Receive_DMA(&huart1,receiver.rxBuffer,PROTOCOL_BUFFER_SIZE);
//             // decode
//             decodeCommand(&receiver);
//            HAL_UART_Transmit(&huart1,receiver.rxBuffer,receiver.len,10);
//         }
//     }
  /* USER CODE END USART1_IRQn 1 */
}

/**
  * @brief This function handles TIM5 global interrupt.
  */
void TIM5_IRQHandler(void)
{
  /* USER CODE BEGIN TIM5_IRQn 0 */
  /* USER CODE END TIM5_IRQn 0 */
  HAL_TIM_IRQHandler(&htim5);
  /* USER CODE BEGIN TIM5_IRQn 1 */
  updateMotorSpeed(5);
  float feedback[4];
  feedback[0] = encoders[0].rpm;
  feedback[1] = encoders[1].rpm;
  feedback[2] = encoders[2].rpm;
  feedback[3] = encoders[3].rpm;
  float cmd[3];
  cmd[0] = receiver.vx;
  cmd[1] = receiver.vy;
  cmd[2] = receiver.omega;
//  simpleControl(cmd);
  PIDControl(cmd,feedback,&MotorPID);
  uart6Sender.motorFeedbackSpd[0] = encoders[0].rpm;
  uart6Sender.motorFeedbackSpd[1] = encoders[1].rpm;
  uart6Sender.motorFeedbackSpd[2] = encoders[2].rpm;
  uart6Sender.motorFeedbackSpd[3] = encoders[3].rpm;
  solveIK(cmd,uart6Sender.motorReqSpd);
  /* USER CODE END TIM5_IRQn 1 */
}

/**
  * @brief This function handles UART4 global interrupt.
  */
void UART4_IRQHandler(void)
{
  /* USER CODE BEGIN UART4_IRQn 0 */
		  uint32_t tmp_flag = 0;
		     uint32_t temp;
  /* USER CODE END UART4_IRQn 0 */
  HAL_UART_IRQHandler(&huart4);
  /* USER CODE BEGIN UART4_IRQn 1 */
  // USART1在NX用有问题，这里用了UART4
       if(UART4 == huart4.Instance)
       {
           tmp_flag =__HAL_UART_GET_FLAG(&huart4,UART_FLAG_IDLE); //获取IDLE标志�???

           if((tmp_flag != RESET))//idle标志被置RESET
           {
//               recv_end_flag = 1;  // 接受完成标志位置1
               __HAL_UART_CLEAR_IDLEFLAG(&huart4);//清除标志�???

               HAL_UART_DMAStop(&huart4); //
               temp  =  __HAL_DMA_GET_COUNTER(&hdma_uart4_rx);// 获取DMA中未传输的数据个�???
               receiver.len =  PROTOCOL_BUFFER_SIZE - temp; //总计数减去未传输的数据个数，得到已经接收的数据个�???

               HAL_UART_Receive_DMA(&huart4,receiver.rxBuffer,PROTOCOL_BUFFER_SIZE);
               // decode
               decodeCommand(&receiver);
           }
       }
  /* USER CODE END UART4_IRQn 1 */
}

/**
  * @brief This function handles DMA2 channel3 global interrupt.
  */
void DMA2_Channel3_IRQHandler(void)
{
  /* USER CODE BEGIN DMA2_Channel3_IRQn 0 */

  /* USER CODE END DMA2_Channel3_IRQn 0 */
  HAL_DMA_IRQHandler(&hdma_uart4_rx);
  /* USER CODE BEGIN DMA2_Channel3_IRQn 1 */

  /* USER CODE END DMA2_Channel3_IRQn 1 */
}

/* USER CODE BEGIN 1 */
__weak void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin)
{
	if (GPIO_Pin == HALL_A2_Pin)
	{  // Encoder A
		GPIO_PinState A_level = HAL_GPIO_ReadPin(HALL_A2_GPIO_Port, HALL_A2_Pin);
		GPIO_PinState B_level = HAL_GPIO_ReadPin(HALL_A1_GPIO_Port, HALL_A1_Pin);

	    if (ENCODER_A_DIR)
	    {
	      if (A_level)
	      {
	        if (B_level)
	        {
	        	encoders[ENCODER_A_INDEX].counter++;
	        }
	        else
	        {
	        	encoders[ENCODER_A_INDEX].counter--;
	        }
	      }
	      else
	      {
	        if (B_level)
	        {
	        	encoders[ENCODER_A_INDEX].counter--;
	        }
	        else
	        {
	        	encoders[ENCODER_A_INDEX].counter++;
	        }
	      }
	    }
	    else
	    {
	      if (A_level)
	      {
	        if (B_level)
	        {
	        	encoders[ENCODER_A_INDEX].counter--;
	        }
	        else
	        {
	        	encoders[ENCODER_A_INDEX].counter++;
	        }
	      }
	      else
	      {
	        if (B_level)
	        {
	        	encoders[ENCODER_A_INDEX].counter++;
	        }
	        else
	        {
	        	encoders[ENCODER_A_INDEX].counter--;
	        }
	      }
	    }
	}
	else if (GPIO_Pin == HALL_B2_Pin)
	{  // Encoder B
		GPIO_PinState A_level = HAL_GPIO_ReadPin(HALL_B2_GPIO_Port, HALL_B2_Pin);
		GPIO_PinState B_level = HAL_GPIO_ReadPin(HALL_B1_GPIO_Port, HALL_B1_Pin);
		if (ENCODER_B_DIR)
		    {
		      if (A_level)
		      {
		        if (B_level)
		        {
		        	encoders[ENCODER_B_INDEX].counter++;
		        }
		        else
		        {
		        	encoders[ENCODER_B_INDEX].counter--;
		        }
		      }
		      else
		      {
		        if (B_level)
		        {
		        	encoders[ENCODER_B_INDEX].counter--;
		        }
		        else
		        {
		        	encoders[ENCODER_B_INDEX].counter++;
		        }
		      }
		    }
		    else
		    {
		      if (A_level)
		      {
		        if (B_level)
		        {
		        	encoders[ENCODER_B_INDEX].counter--;
		        }
		        else
		        {
		        	encoders[ENCODER_B_INDEX].counter++;
		        }
		      }
		      else
		      {
		        if (B_level)
		        {
		        	encoders[ENCODER_B_INDEX].counter++;
		        }
		        else
		        {
		        	encoders[ENCODER_B_INDEX].counter--;
		        }
		      }
		    }
	}
	else if (GPIO_Pin == HALL_C2_Pin)
	{  // Encoder C
		GPIO_PinState A_level = HAL_GPIO_ReadPin(HALL_C2_GPIO_Port, HALL_C2_Pin);
		GPIO_PinState B_level = HAL_GPIO_ReadPin(HALL_C1_GPIO_Port, HALL_C1_Pin);
		if (ENCODER_C_DIR)
		    {
		      if (A_level)
		      {
		        if (B_level)
		        {
		        	encoders[ENCODER_C_INDEX].counter++;
		        }
		        else
		        {
		        	encoders[ENCODER_C_INDEX].counter--;
		        }
		      }
		      else
		      {
		        if (B_level)
		        {
		        	encoders[ENCODER_C_INDEX].counter--;
		        }
		        else
		        {
		        	encoders[ENCODER_C_INDEX].counter++;
		        }
		      }
		    }
		    else
		    {
		      if (A_level)
		      {
		        if (B_level)
		        {
		        	encoders[ENCODER_C_INDEX].counter--;
		        }
		        else
		        {
		        	encoders[ENCODER_C_INDEX].counter++;
		        }
		      }
		      else
		      {
		        if (B_level)
		        {
		        	encoders[ENCODER_C_INDEX].counter++;
		        }
		        else
		        {
		        	encoders[ENCODER_C_INDEX].counter--;
		        }
		      }
		    }
	}
	else if (GPIO_Pin == HALL_D2_Pin)
	{  // Encoder D
		GPIO_PinState A_level = HAL_GPIO_ReadPin(HALL_D2_GPIO_Port, HALL_D2_Pin);
		GPIO_PinState B_level = HAL_GPIO_ReadPin(HALL_D1_GPIO_Port, HALL_D1_Pin);
		if (ENCODER_D_DIR)
		    {
		      if (A_level)
		      {
		        if (B_level)
		        {
		        	encoders[ENCODER_D_INDEX].counter++;
		        }
		        else
		        {
		        	encoders[ENCODER_D_INDEX].counter--;
		        }
		      }
		      else
		      {
		        if (B_level)
		        {
		        	encoders[ENCODER_D_INDEX].counter--;
		        }
		        else
		        {
		        	encoders[ENCODER_D_INDEX].counter++;
		        }
		      }
		    }
		    else
		    {
		      if (A_level)
		      {
		        if (B_level)
		        {
		        	encoders[ENCODER_D_INDEX].counter--;
		        }
		        else
		        {
		        	encoders[ENCODER_D_INDEX].counter++;
		        }
		      }
		      else
		      {
		        if (B_level)
		        {
		        	encoders[ENCODER_D_INDEX].counter++;
		        }
		        else
		        {
		        	encoders[ENCODER_D_INDEX].counter--;
		        }
		      }
		    }
	}
	else
	{

	}

}
/* USER CODE END 1 */
